jQuery(function ($) {
  $(".icon-person").click(function () {
    $(".gnb").stop().slideToggle("fast");
  });
});
